# License

You can use this freebie in your personal or commercial projects (no credit required) with the exception of redistribution, republishing or sale of the item itself, parts of the item, or edited versions.

Read more here: [Codrops license](http://tympanus.net/codrops/licensing/)

[© Codrops 2016](http://www.codrops.com)







